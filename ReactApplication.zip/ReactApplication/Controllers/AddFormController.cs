﻿using ReactApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ReactApplication.Controllers
{
    public class AddFormController : Controller
    {
        // GET: AddForm
        public ActionResult Index()
        {
            return View();
        }

    }
}